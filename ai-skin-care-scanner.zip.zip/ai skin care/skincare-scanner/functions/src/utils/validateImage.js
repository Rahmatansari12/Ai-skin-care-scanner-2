// =====================================================================
// IMAGE VALIDATION — runs server-side before any AI call is made.
// =====================================================================

const MAX_BYTES = 6 * 1024 * 1024; // 6MB, keep in sync with public/js/camera.js // CHANGE THIS HERE
const ALLOWED_MIME = ["image/jpeg", "image/png", "image/webp"];

/**
 * Accepts a base64 data URL (e.g. "data:image/jpeg;base64,...") and returns
 * { ok: true, buffer, mime } or { ok: false, code }.
 */
function validateImageDataUrl(dataUrl) {
  if (typeof dataUrl !== "string" || !dataUrl.startsWith("data:")) {
    return { ok: false, code: "invalid_image" };
  }

  const match = dataUrl.match(/^data:([^;]+);base64,(.+)$/);
  if (!match) {
    return { ok: false, code: "invalid_image" };
  }

  const [, mime, base64Payload] = match;
  if (!ALLOWED_MIME.includes(mime)) {
    return { ok: false, code: "invalid_type" };
  }

  let buffer;
  try {
    buffer = Buffer.from(base64Payload, "base64");
  } catch {
    return { ok: false, code: "invalid_image" };
  }

  if (!buffer || buffer.length === 0) {
    return { ok: false, code: "invalid_image" };
  }

  if (buffer.length > MAX_BYTES) {
    return { ok: false, code: "too_large" };
  }

  return { ok: true, buffer, mime };
}

module.exports = { validateImageDataUrl, MAX_BYTES, ALLOWED_MIME };
