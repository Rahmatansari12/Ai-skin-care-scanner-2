// =====================================================================
// RECOMMENDATION ENGINE — lightweight server-side mirror of the routine
// data in public/js/skincareData.js. The result endpoint returns just the
// raw skinType + concerns; the frontend renders the full guide using its
// own copy of this content so it stays easy to re-brand from one file.
// This module exists for completeness / for any server-rendered use case,
// and to keep validation logic (e.g. known skin types) in one place.
// =====================================================================

const KNOWN_SKIN_TYPES = ["oily", "dry", "combination", "normal", "sensitive", "unknown"]; // CHANGE THIS HERE

function normalizeSkinType(skinType) {
  const normalized = (skinType || "unknown").toLowerCase();
  return KNOWN_SKIN_TYPES.includes(normalized) ? normalized : "unknown";
}

function normalizeConcerns(concerns) {
  if (!Array.isArray(concerns)) return [];
  return concerns
    .filter((c) => typeof c === "string" && c.trim().length > 0)
    .slice(0, 6)
    .map((c) => c.trim().toLowerCase());
}

module.exports = { KNOWN_SKIN_TYPES, normalizeSkinType, normalizeConcerns };
