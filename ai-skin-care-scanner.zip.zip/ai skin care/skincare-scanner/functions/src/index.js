// =====================================================================
// analyzeSkin — the single HTTPS Cloud Function the frontend calls.
// Handles CORS, validation, soft rate limiting, provider selection,
// and never leaks raw provider errors or secrets to the client.
// =====================================================================

require("dotenv").config();
const { onRequest } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const logger = require("firebase-functions/logger");

const { validateImageDataUrl } = require("./utils/validateImage");
const { getProvider } = require("./providers/providerFactory");
const { normalizeSkinType, normalizeConcerns } = require("./data/recommendationEngine");

// CHANGE THIS HERE — bind AI_API_KEY as a Cloud Functions secret for production.
// Set it with: firebase functions:secrets:set AI_API_KEY
const AI_API_KEY_SECRET = defineSecret("AI_API_KEY");

// ---- Soft in-memory rate limiting (per instance; resets on cold start) ----
const requestLog = new Map(); // ip -> [timestamps]
const MAX_REQUESTS_PER_MINUTE = Number(process.env.MAX_REQUESTS_PER_MINUTE || 10); // CHANGE THIS HERE

function isRateLimited(ip) {
  const now = Date.now();
  const windowMs = 60 * 1000;
  const timestamps = (requestLog.get(ip) || []).filter((t) => now - t < windowMs);
  timestamps.push(now);
  requestLog.set(ip, timestamps);
  return timestamps.length > MAX_REQUESTS_PER_MINUTE;
}

function setCors(res) {
  // CHANGE THIS HERE — restrict to your production domain(s) once deployed,
  // e.g. res.set("Access-Control-Allow-Origin", "https://your-app.web.app");
  res.set("Access-Control-Allow-Origin", "*");
  res.set("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.set("Access-Control-Allow-Headers", "Content-Type");
}

exports.analyzeSkin = onRequest(
  { secrets: [AI_API_KEY_SECRET], cors: true, region: "us-central1", memory: "512MiB", timeoutSeconds: 30 },
  async (req, res) => {
    setCors(res);

    if (req.method === "OPTIONS") {
      res.status(204).send("");
      return;
    }

    if (req.method !== "POST") {
      res.status(405).json({ error: "method_not_allowed", message: "Use POST." });
      return;
    }

    const ip = req.headers["x-forwarded-for"] || req.ip || "unknown";
    if (isRateLimited(ip)) {
      res.status(429).json({
        error: "rate_limited",
        message: "Service is temporarily busy. Please try again later.",
      });
      return;
    }

    const { image } = req.body || {};
    const validated = validateImageDataUrl(image);
    if (!validated.ok) {
      const messages = {
        invalid_image: "Please upload a clear face photo.",
        invalid_type: "Unsupported image type. Please use JPG, PNG, or WEBP.",
        too_large: "That image is too large. Please use a smaller photo.",
      };
      res.status(400).json({
        error: validated.code,
        message: messages[validated.code] || "Please upload a clear face photo.",
      });
      return;
    }

    const env = {
      AI_PROVIDER: process.env.AI_PROVIDER || "demo",
      AI_API_KEY: AI_API_KEY_SECRET.value() || process.env.AI_API_KEY || "",
      AI_API_ENDPOINT: process.env.AI_API_ENDPOINT || "",
      AI_MODEL: process.env.AI_MODEL || "",
      DEMO_MODE: process.env.DEMO_MODE || "true",
    };

    const { provider, isDemo } = getProvider(env);

    try {
      const analysis = await provider.analyzeSkinImage(
        { buffer: validated.buffer, mime: validated.mime },
        env
      );

      res.status(200).json({
        demoMode: isDemo || !!analysis.demoMode,
        skinType: normalizeSkinType(analysis.skinType),
        concerns: normalizeConcerns(analysis.concerns),
        confidenceNote: analysis.confidenceNote,
      });
    } catch (err) {
      logger.error("Skin analysis failed", { message: err.message });
      res.status(502).json({
        error: "service_unavailable",
        message: "Skin analysis is temporarily unavailable. Please try again.",
      });
    }
  }
);
