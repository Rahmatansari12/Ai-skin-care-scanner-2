// =====================================================================
// OPENAI PROVIDER — example real provider using an OpenAI-compatible
// vision/chat-completions endpoint. Copy this file to create another
// provider (e.g. Anthropic, Google Vision, a custom model host) and
// register it in providerFactory.js.
// =====================================================================

const SYSTEM_PROMPT = `You are an assistant that describes ONLY visible, surface-level
characteristics of skin in a photo for a non-medical, informational skincare app.

Rules:
- Never diagnose a medical condition or disease (no "eczema", "psoriasis", "cancer", etc).
- Only describe visible characteristics: estimated skin type, oiliness, dryness,
  visible acne/pimples, visible dark spots, uneven skin tone, visible redness,
  visible texture, visible pores, fine-line appearance, under-eye appearance.
- Respond ONLY with strict JSON, no other text, in exactly this shape:
  {"skinType": "oily|dry|combination|normal|sensitive", "concerns": ["short phrase", "..."]}
- List at most 4 concerns, using short lowercase phrases.
- If the image does not clearly show a face, return {"skinType": "unknown", "concerns": []}.`;

async function callVisionModel({ buffer, mime }, env) {
  const base64 = buffer.toString("base64");

  const response = await fetch(env.AI_API_ENDPOINT, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${env.AI_API_KEY}`, // CHANGE THIS HERE if your provider uses a different auth header
    },
    body: JSON.stringify({
      model: env.AI_MODEL, // CHANGE THIS HERE
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        {
          role: "user",
          content: [
            { type: "text", text: "Analyze the visible skin characteristics in this photo." },
            { type: "image_url", image_url: { url: `data:${mime};base64,${base64}` } },
          ],
        },
      ],
      max_tokens: 300,
      temperature: 0.2,
    }),
  });

  if (!response.ok) {
    const text = await response.text().catch(() => "");
    throw new Error(`AI provider error (${response.status}): ${text.slice(0, 300)}`);
  }

  const data = await response.json();
  const raw = data?.choices?.[0]?.message?.content?.trim() || "{}";

  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    // Model didn't return clean JSON — fail safe rather than guessing.
    throw new Error("AI provider returned an unparseable response");
  }
  return parsed;
}

async function analyzeSkinImage(image, env) {
  const result = await callVisionModel(image, env);
  return {
    demoMode: false,
    skinType: result.skinType || "unknown",
    concerns: Array.isArray(result.concerns) ? result.concerns.slice(0, 4) : [],
  };
}

/** Routine/product mapping is handled by the shared recommendationEngine — this
 * hook exists so a provider could override it with a model-generated plan instead. */
async function generateSkinCarePlan(analysis) {
  return { demoMode: false, skinType: analysis.skinType, concerns: analysis.concerns };
}

async function generateFoodGuidance(/* analysis, env */) {
  // Kept static/non-AI-generated intentionally — food guidance is general
  // wellness advice, not something we want a model improvising medically.
  return {
    demoMode: false,
    guidance: [
      "Maintain a balanced diet with a variety of whole foods.",
      "Stay adequately hydrated throughout the day.",
      "Get sufficient, consistent sleep.",
    ],
  };
}

module.exports = { analyzeSkinImage, generateSkinCarePlan, generateFoodGuidance };
