// =====================================================================
// PROVIDER FACTORY — swap AI providers without touching the rest of the app.
// =====================================================================

const demoProvider = require("./demoProvider");
const openaiProvider = require("./openaiProvider");

// CHANGE THIS HERE — register any additional providers you add.
const PROVIDERS = {
  demo: demoProvider,
  openai: openaiProvider,
  // yourProvider: require("./yourProvider"),
};

/**
 * Returns the active provider module, and whether the app should actually
 * be treated as running in demo mode (no key configured, or DEMO_MODE=true).
 */
function getProvider(env) {
  const forcedDemo = String(env.DEMO_MODE).toLowerCase() === "true";
  const noKeyConfigured = !env.AI_API_KEY || env.AI_API_KEY.trim() === "";
  const requestedProvider = (env.AI_PROVIDER || "demo").toLowerCase();

  const useDemo = forcedDemo || noKeyConfigured || requestedProvider === "demo";
  const provider = useDemo ? demoProvider : PROVIDERS[requestedProvider];

  if (!provider) {
    // Unknown provider name configured — fail safe into demo mode rather
    // than crashing the whole function.
    return { provider: demoProvider, isDemo: true, fellBackFromUnknownProvider: true };
  }

  return { provider, isDemo: useDemo };
}

module.exports = { getProvider, PROVIDERS };
