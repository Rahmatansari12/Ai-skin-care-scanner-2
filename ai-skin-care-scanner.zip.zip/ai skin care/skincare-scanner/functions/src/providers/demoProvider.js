// =====================================================================
// DEMO PROVIDER — always available, never calls a real AI API.
// Used automatically when AI_API_KEY is blank or DEMO_MODE=true.
// =====================================================================

const SAMPLE_TYPES = ["oily", "dry", "combination", "normal", "sensitive"];
const SAMPLE_CONCERN_POOL = [
  "oiliness in T-zone",
  "visible uneven tone",
  "mild dryness",
  "visible pores",
  "mild redness",
  "fine-line appearance",
];

function pick(arr, n) {
  const shuffled = [...arr].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, n);
}

/** Simulates analyzing an image. Never inspects the real image content. */
async function analyzeSkinImage(/* imageBuffer, mime */) {
  const skinType = SAMPLE_TYPES[Math.floor(Math.random() * SAMPLE_TYPES.length)];
  const concerns = pick(SAMPLE_CONCERN_POOL, 2 + Math.floor(Math.random() * 2));
  return {
    demoMode: true,
    skinType,
    concerns,
    confidenceNote: "Sample demo data — not generated from your photo.",
  };
}

/** Demo mode defers routine/product mapping to the shared recommendationEngine. */
async function generateSkinCarePlan(analysis) {
  return { demoMode: true, skinType: analysis.skinType, concerns: analysis.concerns };
}

async function generateFoodGuidance(/* analysis */) {
  return {
    demoMode: true,
    guidance: [
      "Maintain a balanced diet with a variety of whole foods.",
      "Stay adequately hydrated throughout the day.",
      "Get sufficient, consistent sleep.",
    ],
  };
}

module.exports = { analyzeSkinImage, generateSkinCarePlan, generateFoodGuidance };
