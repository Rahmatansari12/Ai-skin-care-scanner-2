# AI Skin Care Scanner

A simple, lightweight, mobile-first web app that lets a user take (or upload) a
face photo, sends it through a secure Firebase Cloud Function to an AI vision
provider, and shows back a non-medical, informational skincare guide: estimated
skin type, possible visible concerns, a morning routine, a night routine, food
& lifestyle guidance, things to avoid, and a dermatologist reminder.

**This app never diagnoses medical conditions.** All language is written as
"AI-based skin analysis" / "possible visible concern" / "not a medical
diagnosis." See `SAFETY.md` wording embedded in `public/js/skincareData.js`.

---

## 1. Project structure

```
skincare-scanner/
├── public/                    # Static frontend — deployed to Firebase Hosting
│   ├── index.html             # Single-page app shell (home, scan, result, legal views)
│   ├── privacy.html
│   ├── terms.html
│   ├── css/style.css
│   ├── assets/                # logo.svg, favicon.svg
│   └── js/
│       ├── config.js          # <-- MAIN FILE YOU EDIT: branding, colors, feature flags
│       ├── products.json      # Product-category recommendation database
│       ├── skincareData.js    # Routines, food guidance, avoid list, demo sample data
│       ├── api.js             # Talks to the Cloud Function (never talks to AI directly)
│       ├── camera.js          # Camera capture / upload / compression
│       └── app.js             # App wiring: view routing + event handlers
│
├── functions/                 # Firebase Cloud Functions — deployed backend
│   ├── package.json
│   ├── .env.example           # <-- COPY TO functions/.env AND FILL IN YOUR KEYS
│   └── src/
│       ├── index.js           # HTTPS function `analyzeSkin` (entry point)
│       ├── providers/
│       │   ├── providerFactory.js   # Picks provider based on AI_PROVIDER env var
│       │   ├── demoProvider.js      # Built-in DEMO MODE, no API key required
│       │   └── openaiProvider.js    # Example real provider (OpenAI-compatible vision API)
│       ├── data/recommendationEngine.js  # Maps analysis -> routines/products/food
│       └── utils/validateImage.js
│
├── firebase.json
├── .firebaserc                # <-- SET YOUR FIREBASE PROJECT ID HERE
├── .gitignore
├── .env.example                # documents ALL env vars used across the project
└── README.md
```

Nothing here needs a JS bundler. The frontend is plain HTML/CSS/JS (ES
modules), so `public/` can be deployed to Firebase Hosting as-is.

---

## 2. How the pieces fit together

1. The browser captures/uploads a photo (`public/js/camera.js`), compresses it,
   and calls `public/js/api.js`.
2. `api.js` POSTs the image (base64) to the Cloud Function URL — **never**
   directly to any AI provider, so your AI API key is never in the browser.
3. `functions/src/index.js` validates the image, then calls
   `providerFactory.js`, which picks either:
   - `demoProvider.js` (no key needed — safe, sample results), or
   - `openaiProvider.js` (or whichever real provider you wire up), using the
     secret key from `functions/.env` (never committed to GitHub).
4. The function returns a plain analysis JSON. The frontend maps that through
   `recommendationEngine.js`'s output (routines, products, food guidance,
   avoid list, dermatologist note) and renders the result page.

If no AI key is configured, the backend automatically falls back to
**DEMO_MODE** and clearly labels results as demo/sample data.

---

## 3. Install & run locally

### Prerequisites
- Node.js 20+
- A free [Firebase](https://firebase.google.com/) account
- The Firebase CLI: `npm install -g firebase-tools`

### 3.1 Clone and install function dependencies
```bash
git clone <your-repo-url> skincare-scanner
cd skincare-scanner
cd functions
npm install
cd ..
```

### 3.2 Configure environment variables
```bash
cp .env.example .env                      # reference/documentation only
cp functions/.env.example functions/.env  # THIS is the one Functions actually reads
```
Edit `functions/.env`:
```
AI_PROVIDER=demo          # "demo" or "openai" (or add your own provider)
AI_API_KEY=               # leave blank to stay in demo mode
AI_API_ENDPOINT=https://api.openai.com/v1/chat/completions
AI_MODEL=gpt-4o-mini
DEMO_MODE=true            # set to false once AI_API_KEY is filled in
```

### 3.3 Run locally with the Firebase Emulator
```bash
firebase login
firebase init emulators     # choose Hosting + Functions if prompted, or use the provided firebase.json
firebase emulators:start
```
Open the printed Hosting URL (usually `http://127.0.0.1:5000`).

Frontend-only quick preview (no backend, demo data hard-coded) also works by
opening `public/index.html` through any static file server, e.g.:
```bash
npx serve public
```

---

## 4. Create your Firebase project

```bash
firebase login
firebase projects:create your-project-id   # or use an existing project in the console
```
Edit `.firebaserc` and replace `"default": "CHANGE_THIS_HERE"` with your real
project ID.

Enable these in the [Firebase Console](https://console.firebase.google.com/):
- **Hosting**
- **Functions** (needs the Blaze pay-as-you-go plan — the free tier quota is
  generous and typically costs $0 for small personal projects)
- **Firestore** — only if you plan to use the optional admin panel /
  editable product database instead of the static JSON file

---

## 5. Add your AI API key (backend only, never frontend)

**Never put a real API key in `public/js/config.js`, in any HTML/CSS/JS file,
or commit it to GitHub.** Keys only ever live in `functions/.env`
(git-ignored) or in a real secret manager.

For local + emulator use:
```
functions/.env
  AI_PROVIDER=openai
  AI_API_KEY=sk-xxxxxxxx        # <-- CHANGE THIS HERE
  AI_API_ENDPOINT=https://api.openai.com/v1/chat/completions
  AI_MODEL=gpt-4o-mini
  DEMO_MODE=false
```

For production deploys, set the same values as a Cloud Functions **secret**
so the raw key is never stored in your repo or in plaintext config:
```bash
firebase functions:secrets:set AI_API_KEY
# paste your key when prompted
```
`functions/src/index.js` already references `AI_API_KEY` as a secret binding
— see the `CHANGE THIS HERE` comment near the top of that file.

### Swapping the AI provider
1. Duplicate `functions/src/providers/openaiProvider.js` →
   `functions/src/providers/yourProvider.js`, and implement:
   `analyzeSkinImage()`, `generateSkinCarePlan()`, `generateFoodGuidance()`.
2. Register it in `functions/src/providers/providerFactory.js`
   (`CHANGE THIS HERE` comment marks the spot).
3. Set `AI_PROVIDER=yourProvider` in `functions/.env` / secrets.

---

## 6. Customize branding & content

Everything non-secret lives in **one file**: `public/js/config.js`.
Edit these `CHANGE THIS HERE` fields:

```js
APP_NAME, APP_LOGO, APP_DESCRIPTION,
PRIMARY_COLOR, SECONDARY_COLOR,
AI_PROVIDER, AI_MODEL,
ENABLE_CAMERA, ENABLE_IMAGE_UPLOAD,
ENABLE_FOOD_RECOMMENDATIONS, ENABLE_DERMATOLOGIST_WARNING
```

Skincare content (routines, food guidance, avoid list, disclaimer wording,
demo sample analysis) lives in `public/js/skincareData.js` — plain
JavaScript objects/arrays, safe for a non-technical person to edit carefully.

The product recommendation database is `public/js/products.json` — a plain
JSON array, one object per category, matching the structure requested:
```json
{
  "category": "Moisturizer",
  "skinTypes": ["dry", "combination"],
  "concerns": ["dryness"],
  "recommendedIngredients": ["ceramides", "glycerin"],
  "avoidIngredients": [],
  "usage": "Use after cleansing, morning and night."
}
```
Add, remove, or edit entries freely — no code changes required. (If you later
want an admin UI instead of hand-editing JSON, move this array into a
Firestore collection — the frontend already reads it through a single
`loadProducts()` function in `products.json`'s loader inside `app.js`, so
swapping the data source is a one-function change.)

Logo/favicon: replace `public/assets/logo.svg` and
`public/assets/favicon.svg`.

---

## 7. Deploy

### Deploy Hosting only
```bash
firebase deploy --only hosting
```

### Deploy Functions only
```bash
firebase deploy --only functions
```

### Deploy everything
```bash
firebase deploy
```

Your live site will be at `https://<your-project-id>.web.app`.

### Connect GitHub for automatic deploys (optional)
```bash
firebase init hosting:github
```
This creates a GitHub Actions workflow that deploys a preview on every pull
request and deploys to production on merges to your main branch. Follow the
CLI prompts to authorize the Firebase GitHub App.

---

## 8. Security notes

- `functions/.env` and any real `.env` files are listed in `.gitignore` —
  double-check they never get committed.
- Images are processed in memory in the Cloud Function and are **not**
  stored anywhere by default (see Privacy Policy in `public/privacy.html`).
- File type and file size are validated server-side
  (`functions/src/utils/validateImage.js`) before any AI call is made.
- Firestore rules (`firestore.rules`) default to fully locked down — open
  them up only for the specific collections you actually use (e.g. an admin
  panel), and always gate writes behind Firebase Auth + custom admin claims.
- Basic per-IP rate limiting is included in `functions/src/index.js`
  (in-memory — for serious abuse protection at scale, add
  [Firebase App Check](https://firebase.google.com/docs/app-check) and/or
  Cloud Armor).

---

## 9. Legal / disclaimers

`public/privacy.html` and `public/terms.html` are starting templates. You
must review them with your own legal counsel before using this for real
users — they are not legal advice.

---

## 10. Roadmap ideas (not built yet, by design — keep v1 simple)

- Firestore-backed admin panel with Firebase Auth for editing branding/data
  through a UI instead of files
- User accounts / scan history
- Affiliate product links
- Subscription tiers
- Native mobile wrapper (Capacitor/React Native)
