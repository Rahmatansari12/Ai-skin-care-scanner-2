// =====================================================================
// APP CONFIGURATION — the ONE file to edit for branding & feature flags.
// Nothing secret goes in this file — it is loaded straight into the browser.
// =====================================================================

export const CONFIG = {
  // ---- Branding ----
  APP_NAME: "AI Skin Care Scanner",          // CHANGE THIS HERE
  APP_LOGO: "/assets/logo.svg",              // CHANGE THIS HERE (path under /public)
  APP_FAVICON: "/assets/favicon.svg",        // CHANGE THIS HERE
  APP_DESCRIPTION:
    "Scan your face and get a personalized, AI-based skincare guide.", // CHANGE THIS HERE

  // ---- Colors (also mirrored as CSS variables in css/style.css) ----
  PRIMARY_COLOR: "#2F6F5E",     // CHANGE THIS HERE — deep sage green
  SECONDARY_COLOR: "#F2A65A",   // CHANGE THIS HERE — warm apricot accent
  BACKGROUND_COLOR: "#FBF8F3",  // CHANGE THIS HERE — soft warm off-white
  TEXT_COLOR: "#1F2A27",        // CHANGE THIS HERE

  // ---- Fonts ----
  FONT_DISPLAY: "'Fraunces', serif",     // CHANGE THIS HERE
  FONT_BODY: "'Inter', sans-serif",      // CHANGE THIS HERE

  // ---- Homepage copy ----
  HOME_HEADLINE: "Know your skin. Care for it better.",  // CHANGE THIS HERE
  HOME_SUBTEXT:
    "Take a quick photo and get an AI-based skincare guide in under a minute.", // CHANGE THIS HERE
  SCAN_BUTTON_TEXT: "SCAN MY FACE",          // CHANGE THIS HERE
  UPLOAD_BUTTON_TEXT: "UPLOAD PHOTO",        // CHANGE THIS HERE

  // ---- AI provider (informational only — the REAL key lives in functions/.env) ----
  AI_PROVIDER: "demo",        // CHANGE THIS HERE — must match functions/.env AI_PROVIDER
  AI_MODEL: "gpt-4o-mini",    // CHANGE THIS HERE — shown in the UI's "Demo Mode" badge only

  // ---- Feature flags ----
  ENABLE_CAMERA: true,                 // CHANGE THIS HERE
  ENABLE_IMAGE_UPLOAD: true,           // CHANGE THIS HERE
  ENABLE_FOOD_RECOMMENDATIONS: true,   // CHANGE THIS HERE
  ENABLE_DERMATOLOGIST_WARNING: true,  // CHANGE THIS HERE

  // ---- Backend endpoint ----
  // Local emulator default shown below. In production this is automatically
  // swapped to your deployed Cloud Function URL by api.js (see getApiBase()).
  FUNCTIONS_EMULATOR_URL:
    "http://127.0.0.1:5001/CHANGE_THIS_HERE/us-central1/analyzeSkin", // CHANGE THIS HERE (your project id)
  PRODUCTION_FUNCTION_URL:
    "https://us-central1-CHANGE_THIS_HERE.cloudfunctions.net/analyzeSkin", // CHANGE THIS HERE (your project id)

  // ---- Legal ----
  MEDICAL_DISCLAIMER:
    "AI skin analysis is not a medical diagnosis. If you have persistent, painful, rapidly changing, infected, or otherwise concerning skin changes, please consult a qualified dermatologist.", // CHANGE THIS HERE
};
