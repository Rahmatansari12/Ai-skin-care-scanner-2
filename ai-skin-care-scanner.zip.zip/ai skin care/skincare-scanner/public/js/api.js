// =====================================================================
// API CLIENT — the ONLY place the frontend talks to the backend.
// It never calls any AI provider directly, and never sees any secret key.
// =====================================================================

import { CONFIG } from "./config.js";
import { DEMO_SAMPLE_RESULT } from "./skincareData.js";

function getApiBase() {
  const isLocal =
    location.hostname === "localhost" || location.hostname === "127.0.0.1";
  return isLocal ? CONFIG.FUNCTIONS_EMULATOR_URL : CONFIG.PRODUCTION_FUNCTION_URL;
}

/**
 * Sends a base64 JPEG data URL to the Cloud Function for analysis.
 * Returns { demoMode, skinType, concerns, error? }.
 * Falls back to local demo data if the backend cannot be reached at all,
 * so the app still works before you've deployed a function.
 */
export async function analyzeSkinImage(imageDataUrl) {
  try {
    const res = await fetch(getApiBase(), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ image: imageDataUrl }),
    });

    if (!res.ok) {
      const body = await safeJson(res);
      return {
        error: body?.error || "service_unavailable",
        message: body?.message || "Skin analysis is temporarily unavailable. Please try again.",
      };
    }
    return await res.json();
  } catch (err) {
    // Backend unreachable (e.g. not deployed yet during local frontend-only preview).
    return {
      ...DEMO_SAMPLE_RESULT,
      offlineFallback: true,
    };
  }
}

async function safeJson(res) {
  try {
    return await res.json();
  } catch {
    return null;
  }
}
