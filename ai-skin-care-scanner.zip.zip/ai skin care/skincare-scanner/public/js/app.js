import { CONFIG } from "./config.js";
import {
  ROUTINES,
  FOOD_LIFESTYLE_GUIDANCE,
  THINGS_TO_AVOID,
  DERMATOLOGIST_MESSAGE,
  CAMERA_INSTRUCTIONS,
} from "./skincareData.js";
import { startCamera, stopCamera, captureFromVideo, processUploadedFile, isCameraSupported } from "./camera.js";
import { analyzeSkinImage } from "./api.js";

// ---------------------------------------------------------------------
// Boot: apply branding from CONFIG
// ---------------------------------------------------------------------
document.title = CONFIG.APP_NAME;
document.documentElement.style.setProperty("--color-primary", CONFIG.PRIMARY_COLOR);
document.documentElement.style.setProperty("--color-secondary", CONFIG.SECONDARY_COLOR);
document.documentElement.style.setProperty("--color-bg", CONFIG.BACKGROUND_COLOR);
document.documentElement.style.setProperty("--color-text", CONFIG.TEXT_COLOR);
document.documentElement.style.setProperty("--font-display", CONFIG.FONT_DISPLAY);
document.documentElement.style.setProperty("--font-body", CONFIG.FONT_BODY);

const favicon = document.getElementById("favicon");
if (favicon) favicon.href = CONFIG.APP_FAVICON;

let productDatabase = [];
let capturedImage = null;

const views = {
  home: document.getElementById("view-home"),
  scan: document.getElementById("view-scan"),
  loading: document.getElementById("view-loading"),
  result: document.getElementById("view-result"),
};

function showView(name) {
  Object.entries(views).forEach(([key, el]) => {
    if (!el) return;
    el.hidden = key !== name;
  });
  if (name !== "scan") stopCamera();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

// ---------------------------------------------------------------------
// Home view
// ---------------------------------------------------------------------
document.getElementById("app-name").textContent = CONFIG.APP_NAME;
document.getElementById("home-headline").textContent = CONFIG.HOME_HEADLINE;
document.getElementById("home-subtext").textContent = CONFIG.HOME_SUBTEXT;

const scanBtn = document.getElementById("btn-scan");
const uploadBtn = document.getElementById("btn-upload");
const uploadInput = document.getElementById("upload-input");

scanBtn.textContent = CONFIG.SCAN_BUTTON_TEXT;
uploadBtn.textContent = CONFIG.UPLOAD_BUTTON_TEXT;

if (!CONFIG.ENABLE_CAMERA) scanBtn.hidden = true;
if (!CONFIG.ENABLE_IMAGE_UPLOAD) uploadBtn.hidden = true;

scanBtn.addEventListener("click", async () => {
  if (!isCameraSupported()) {
    showError("Camera is not supported on this device. Please upload a photo instead.");
    uploadInput.click();
    return;
  }
  showView("scan");
  const video = document.getElementById("camera-video");
  const result = await startCamera(video);
  if (!result.ok) {
    showView("home");
    showError("Please allow camera access or upload a photo.");
  }
});

uploadBtn.addEventListener("click", () => uploadInput.click());

uploadInput.addEventListener("change", async (e) => {
  const file = e.target.files[0];
  e.target.value = "";
  if (!file) return;
  try {
    capturedImage = await processUploadedFile(file);
    runAnalysis();
  } catch (err) {
    if (err.code === "invalid_type") {
      showError("Please upload a clear photo in JPG, PNG, or WEBP format.");
    } else if (err.code === "too_large") {
      showError("That image is too large. Please upload a photo under 6MB.");
    } else {
      showError("Please upload a clear face photo.");
    }
  }
});

// ---------------------------------------------------------------------
// Scan view (camera)
// ---------------------------------------------------------------------
const instructionsList = document.getElementById("camera-instructions");
instructionsList.innerHTML = CAMERA_INSTRUCTIONS.map((i) => `<li>${escapeHtml(i)}</li>`).join("");

document.getElementById("btn-capture").addEventListener("click", () => {
  const video = document.getElementById("camera-video");
  capturedImage = captureFromVideo(video);
  runAnalysis();
});

document.getElementById("btn-cancel-scan").addEventListener("click", () => {
  showView("home");
});

document.getElementById("btn-use-upload-instead").addEventListener("click", () => {
  showView("home");
  uploadInput.click();
});

// ---------------------------------------------------------------------
// Analysis flow
// ---------------------------------------------------------------------
async function runAnalysis() {
  showView("loading");
  const analysis = await analyzeSkinImage(capturedImage);

  if (analysis.error) {
    showView("home");
    showError(analysis.message || "Skin analysis is temporarily unavailable. Please try again.");
    return;
  }

  await ensureProductsLoaded();
  renderResult(analysis);
  showView("result");
}

async function ensureProductsLoaded() {
  if (productDatabase.length) return;
  try {
    const res = await fetch("/js/products.json");
    productDatabase = await res.json();
  } catch {
    productDatabase = [];
  }
}

// ---------------------------------------------------------------------
// Result rendering
// ---------------------------------------------------------------------
function renderResult(analysis) {
  const demoBadge = document.getElementById("demo-badge");
  demoBadge.hidden = !analysis.demoMode;

  document.getElementById("result-skin-type").textContent = capitalize(analysis.skinType || "unknown");

  const concernsList = document.getElementById("result-concerns");
  concernsList.innerHTML = (analysis.concerns || [])
    .map((c) => `<li>${escapeHtml(capitalize(c))}</li>`)
    .join("") || "<li>No notable concerns detected.</li>";

  const routine = ROUTINES[analysis.skinType] || ROUTINES.default;
  renderRoutine("routine-morning", routine.morning);
  renderRoutine("routine-night", routine.night);

  const foodSection = document.getElementById("section-food");
  if (CONFIG.ENABLE_FOOD_RECOMMENDATIONS) {
    foodSection.hidden = false;
    document.getElementById("food-list").innerHTML = FOOD_LIFESTYLE_GUIDANCE.map(
      (f) => `<li>${escapeHtml(f)}</li>`
    ).join("");
  } else {
    foodSection.hidden = true;
  }

  document.getElementById("avoid-list").innerHTML = THINGS_TO_AVOID.map(
    (a) => `<li>${escapeHtml(a)}</li>`
  ).join("");

  const dermoSection = document.getElementById("section-dermatologist");
  dermoSection.hidden = !CONFIG.ENABLE_DERMATOLOGIST_WARNING;
  document.getElementById("dermatologist-message").textContent = DERMATOLOGIST_MESSAGE;

  renderProducts(analysis);
}

function renderRoutine(elementId, steps) {
  const el = document.getElementById(elementId);
  el.innerHTML = steps
    .map(
      (s, i) => `
      <li class="routine-step">
        <span class="step-number">${i + 1}</span>
        <div>
          <strong>${escapeHtml(s.step)}</strong>
          <p>${escapeHtml(s.detail)}</p>
        </div>
      </li>`
    )
    .join("");
}

function renderProducts(analysis) {
  const skinType = analysis.skinType;
  const concerns = (analysis.concerns || []).map((c) => c.toLowerCase());

  const matches = productDatabase.filter((p) => {
    const typeMatch = p.skinTypes?.includes(skinType);
    const concernMatch = p.concerns?.some((pc) => concerns.some((c) => c.includes(pc)));
    return typeMatch || concernMatch;
  });

  const toShow = matches.length ? matches : productDatabase.slice(0, 3);

  const container = document.getElementById("product-list");
  container.innerHTML = toShow
    .map(
      (p) => `
      <article class="product-card">
        <h4>${escapeHtml(p.category)}</h4>
        <p><strong>Why it may suit you:</strong> ${escapeHtml(p.why)}</p>
        <p><strong>How to use:</strong> ${escapeHtml(p.usage)}</p>
        <p class="precaution"><strong>Precautions:</strong> ${escapeHtml(p.precautions)}</p>
      </article>`
    )
    .join("");
}

document.getElementById("btn-scan-again").addEventListener("click", () => {
  capturedImage = null;
  showView("home");
});

// ---------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------
function showError(message) {
  const banner = document.getElementById("error-banner");
  banner.textContent = message;
  banner.hidden = false;
  clearTimeout(showError._t);
  showError._t = setTimeout(() => (banner.hidden = true), 6000);
}

function capitalize(s) {
  return typeof s === "string" && s.length ? s.charAt(0).toUpperCase() + s.slice(1) : s;
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

showView("home");
