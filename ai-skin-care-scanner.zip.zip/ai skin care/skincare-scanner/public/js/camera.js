// =====================================================================
// CAMERA / UPLOAD — capture a face photo, compress it, hand back a
// compressed base64 JPEG string ready to send to the backend.
// =====================================================================

const MAX_DIMENSION = 900;       // px, longest side after compression   // CHANGE THIS HERE
const JPEG_QUALITY = 0.82;       // 0..1                                  // CHANGE THIS HERE
export const MAX_UPLOAD_BYTES = 6 * 1024 * 1024; // 6MB raw upload cap    // CHANGE THIS HERE
const ACCEPTED_TYPES = ["image/jpeg", "image/png", "image/webp"];

let activeStream = null;

/** Starts the front-facing camera and attaches it to a <video> element. */
export async function startCamera(videoEl) {
  stopCamera();
  try {
    activeStream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: "user", width: { ideal: 720 }, height: { ideal: 960 } },
      audio: false,
    });
    videoEl.srcObject = activeStream;
    await videoEl.play();
    return { ok: true };
  } catch (err) {
    return { ok: false, error: "permission_denied" };
  }
}

export function stopCamera() {
  if (activeStream) {
    activeStream.getTracks().forEach((t) => t.stop());
    activeStream = null;
  }
}

/** Captures the current video frame to a compressed base64 JPEG data URL. */
export function captureFromVideo(videoEl) {
  const canvas = document.createElement("canvas");
  const vw = videoEl.videoWidth || 720;
  const vh = videoEl.videoHeight || 960;
  const scale = Math.min(1, MAX_DIMENSION / Math.max(vw, vh));
  canvas.width = Math.round(vw * scale);
  canvas.height = Math.round(vh * scale);
  const ctx = canvas.getContext("2d");
  // Mirror the preview back so the captured image matches what the user saw.
  ctx.translate(canvas.width, 0);
  ctx.scale(-1, 1);
  ctx.drawImage(videoEl, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL("image/jpeg", JPEG_QUALITY);
}

/** Validates + compresses a user-selected file, returns a base64 JPEG data URL. */
export function processUploadedFile(file) {
  return new Promise((resolve, reject) => {
    if (!ACCEPTED_TYPES.includes(file.type)) {
      reject({ code: "invalid_type" });
      return;
    }
    if (file.size > MAX_UPLOAD_BYTES) {
      reject({ code: "too_large" });
      return;
    }
    const reader = new FileReader();
    reader.onerror = () => reject({ code: "read_failed" });
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject({ code: "invalid_image" });
      img.onload = () => {
        const scale = Math.min(1, MAX_DIMENSION / Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", JPEG_QUALITY));
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

export function isCameraSupported() {
  return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
}
