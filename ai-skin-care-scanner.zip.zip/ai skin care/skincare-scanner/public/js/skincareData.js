// =====================================================================
// SKINCARE CONTENT — plain data, safe to edit without touching app logic.
// Everything here is informational / educational, never a medical claim.
// =====================================================================

// The full list of estimated skin types the AI/demo mode can return.
export const SKIN_TYPES = ["oily", "dry", "combination", "normal", "sensitive"]; // CHANGE THIS HERE

// The full list of possible visible concerns the AI/demo mode can return.
export const SKIN_CONCERNS = [
  "oiliness",
  "dryness",
  "visible acne/pimples",
  "visible dark spots",
  "uneven skin tone",
  "visible redness",
  "visible texture",
  "visible pores",
  "fine-line appearance",
  "under-eye appearance",
]; // CHANGE THIS HERE

// Generic morning/night routines, templated per skin type.
// Keyed by skin type; "default" is used as a fallback.
export const ROUTINES = {
  default: {
    morning: [
      { step: "Gentle Cleanser", detail: "A mild, sulfate-free cleanser to remove overnight buildup without stripping skin." },
      { step: "Optional Serum", detail: "A lightweight serum suited to your main concern (see recommendations below)." },
      { step: "Moisturizer", detail: "Lock in hydration appropriate for your estimated skin type." },
      { step: "Broad-Spectrum Sunscreen (SPF 30+)", detail: "Apply generously as the last step, every day, even indoors." },
    ],
    night: [
      { step: "Gentle Cleanser", detail: "Remove sunscreen, makeup, and the day's buildup." },
      { step: "Appropriate Treatment", detail: "An active ingredient category suited to your main concern, introduced gradually." },
      { step: "Moisturizer", detail: "A slightly richer formula at night to support the skin barrier while you sleep." },
    ],
  },
  oily: {
    morning: [
      { step: "Gentle Foaming Cleanser", detail: "Helps manage excess shine without over-stripping the skin." },
      { step: "Lightweight Hydrating Serum", detail: "Oily skin still needs hydration — look for water-based, non-comedogenic formulas." },
      { step: "Oil-Free Moisturizer", detail: "A gel or lotion texture that hydrates without adding heaviness." },
      { step: "Broad-Spectrum Sunscreen (SPF 30+)", detail: "Choose a matte or gel-based sunscreen to avoid excess shine." },
    ],
    night: [
      { step: "Gentle Cleanser", detail: "Double cleanse only if wearing heavy makeup/sunscreen." },
      { step: "Oil-Balancing Treatment Category", detail: "E.g. niacinamide or salicylic-acid-based products, introduced gradually." },
      { step: "Lightweight Moisturizer", detail: "Skip heavy creams; a gel-based moisturizer is usually enough." },
    ],
  },
  dry: {
    morning: [
      { step: "Cream or Balm Cleanser", detail: "A non-foaming cleanser that won't strip natural oils." },
      { step: "Hydrating Serum", detail: "Look for humectants such as glycerin or hyaluronic acid." },
      { step: "Rich Moisturizer", detail: "A ceramide-rich cream to support the skin barrier." },
      { step: "Broad-Spectrum Sunscreen (SPF 30+)", detail: "A hydrating, cream-based sunscreen works well for dry skin." },
    ],
    night: [
      { step: "Cream Cleanser", detail: "Avoid hot water, which can worsen dryness." },
      { step: "Barrier-Support Treatment Category", detail: "E.g. ceramide or peptide-based products." },
      { step: "Rich Moisturizer / Facial Oil", detail: "Seal in hydration before bed." },
    ],
  },
  combination: {
    morning: [
      { step: "Gentle Balanced Cleanser", detail: "A pH-balanced cleanser suited to mixed skin needs." },
      { step: "Lightweight Hydrating Serum", detail: "Focus hydration on drier areas, lighter layers on the T-zone." },
      { step: "Balanced Moisturizer", detail: "A lotion texture that hydrates without overloading the T-zone." },
      { step: "Broad-Spectrum Sunscreen (SPF 30+)", detail: "A matte-finish sunscreen tends to suit combination skin well." },
    ],
    night: [
      { step: "Gentle Cleanser", detail: "Remove the day's buildup evenly across the face." },
      { step: "Targeted Treatment Category", detail: "Apply oil-balancing products to the T-zone and hydrating products elsewhere." },
      { step: "Balanced Moisturizer", detail: "A medium-weight formula that works across combination skin." },
    ],
  },
  sensitive: {
    morning: [
      { step: "Fragrance-Free Gentle Cleanser", detail: "Minimal ingredient list to reduce the chance of irritation." },
      { step: "Soothing Serum", detail: "Look for calming ingredients such as centella asiatica or panthenol." },
      { step: "Fragrance-Free Moisturizer", detail: "Simple, barrier-supporting formulas." },
      { step: "Mineral Sunscreen (SPF 30+)", detail: "Mineral (zinc oxide/titanium dioxide) sunscreens are often better tolerated." },
    ],
    night: [
      { step: "Gentle Cleanser", detail: "Avoid hot water and vigorous rubbing." },
      { step: "Minimal Treatment", detail: "Introduce any new active ingredient one at a time, and patch test first." },
      { step: "Fragrance-Free Moisturizer", detail: "Prioritize barrier support over active ingredients." },
    ],
  },
  normal: {
    morning: [
      { step: "Gentle Cleanser", detail: "A simple daily cleanser is usually enough." },
      { step: "Optional Antioxidant Serum", detail: "E.g. a vitamin C serum for general skin health." },
      { step: "Lightweight Moisturizer", detail: "Maintain your skin's natural balance." },
      { step: "Broad-Spectrum Sunscreen (SPF 30+)", detail: "Daily sunscreen remains important regardless of skin type." },
    ],
    night: [
      { step: "Gentle Cleanser", detail: "Remove the day's buildup." },
      { step: "Optional Treatment Category", detail: "General maintenance actives such as a gentle retinoid alternative, if desired." },
      { step: "Moisturizer", detail: "Support overnight skin repair." },
    ],
  },
}; // CHANGE THIS HERE

// Food & lifestyle guidance — general wellness tips only, no disease claims.
export const FOOD_LIFESTYLE_GUIDANCE = [
  "Maintain a balanced diet with a variety of whole foods.",
  "Eat a variety of fruits and vegetables.",
  "Stay adequately hydrated throughout the day.",
  "Get sufficient, consistent sleep.",
  "Avoid smoking.",
  "Limit excessive alcohol consumption.",
  "Avoid picking or squeezing pimples.",
  "Change pillowcases and clean phone screens regularly.",
]; // CHANGE THIS HERE

// Things to avoid — general, non-diagnostic guidance.
export const THINGS_TO_AVOID = [
  "Excessive, unprotected sun exposure",
  "Over-exfoliation (more than 2–3 times per week for most skin types)",
  "Harsh or heavily fragranced products if skin feels reactive",
  "Picking or squeezing pimples",
  "Introducing too many new active ingredients at once",
  "Sharing unwashed makeup brushes or applicators",
]; // CHANGE THIS HERE

// Shown on every result page, regardless of analysis outcome.
export const DERMATOLOGIST_MESSAGE =
  "AI skin analysis is not a medical diagnosis. If you notice persistent, painful, rapidly changing, infected, or otherwise concerning skin changes, please consult a qualified dermatologist."; // CHANGE THIS HERE

// A realistic-looking but clearly-labeled sample result used only in Demo Mode
// (also used as a frontend fallback if the backend is unreachable).
export const DEMO_SAMPLE_RESULT = {
  demoMode: true,
  skinType: "combination",
  concerns: ["oiliness in T-zone", "visible uneven tone", "mild dryness on cheeks"],
  confidenceNote:
    "Sample demo data — not generated from your photo. Configure an AI provider to enable real analysis.",
};

// Camera / photo-taking guidance shown to the user before capture.
export const CAMERA_INSTRUCTIONS = [
  "Take the photo in natural light.",
  "Keep your face clearly visible.",
  "Remove sunglasses.",
  "Keep your face straight, facing the camera.",
  "Do not use beauty filters.",
  "Avoid wearing makeup if possible, for a more accurate scan.",
]; // CHANGE THIS HERE
